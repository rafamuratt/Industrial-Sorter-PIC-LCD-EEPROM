#line 1 "C:/Users/Rafamuratt/Documents/1Rafa/005 - Engenharia/1 - Estudos/001 Aulas/C WR Kits/M�dulo 010/10.0 PIC/Object Counter PIC 16F628A/MikroC library/HMI Sorter (min sec)/HMI_Sorter_(min_sec).c"
#line 55 "C:/Users/Rafamuratt/Documents/1Rafa/005 - Engenharia/1 - Estudos/001 Aulas/C WR Kits/M�dulo 010/10.0 PIC/Object Counter PIC 16F628A/MikroC library/HMI Sorter (min sec)/HMI_Sorter_(min_sec).c"
sbit LCD_RS at RB0_bit;
sbit LCD_EN at RB1_bit;
sbit LCD_D4 at RB4_bit;
sbit LCD_D5 at RB5_bit;
sbit LCD_D6 at RB6_bit;
sbit LCD_D7 at RB7_bit;


sbit LCD_RS_Direction at TRISB0_bit;
sbit LCD_EN_Direction at TRISB1_bit;
sbit LCD_D4_Direction at TRISB4_bit;
sbit LCD_D5_Direction at TRISB5_bit;
sbit LCD_D6_Direction at TRISB6_bit;
sbit LCD_D7_Direction at TRISB7_bit;
#line 81 "C:/Users/Rafamuratt/Documents/1Rafa/005 - Engenharia/1 - Estudos/001 Aulas/C WR Kits/M�dulo 010/10.0 PIC/Object Counter PIC 16F628A/MikroC library/HMI Sorter (min sec)/HMI_Sorter_(min_sec).c"
unsigned int obj = 0, sortQty, bkpQty, objTick = 0;
unsigned char adj = 0, pageState = 0, lastPage = 0xFF;
unsigned char totalSortSeconds, objTimeOut = 0;
unsigned short boxes = 0, sortMin, bkpSortMin, sortSec, bkpSortSec;
unsigned short jobLimit, bkpJobLimit;

typedef enum {
 VAL_UNI,
 VAL_DEZ,
 VAL_CEN,
 VAL_MIL,
 VAL_DEZM
} DispFormat;




void refreshUI();
void disp_num(unsigned int num, char row, char col, DispFormat range);

void disp_blink(char row, char col);

void ems_halt() {
  PORTB.B2  = 0;
  PORTB.B3  = 0;
 Lcd_Cmd(0x0C);
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1,5,"EMERGENCY");
  PORTA.B7  = 1;
 while(1);
}

void objectCount();




void main() {
 CMCON = 0x07;
 TRISA = 0x7F;
 PORTA = 0x00;
 TRISB = 0x00;
 PORTB = 0x00;

 Lcd_Init();
 Lcd_Cmd(0x0C);


 Lcd_Out(1,4,"MURAT-TECH");
 Lcd_Chr(2,6,'S');
 Lcd_Chr_Cp('O');
 Lcd_Chr_Cp('R');
 Lcd_Chr_Cp('T');
 Lcd_Chr_Cp('E');
 Lcd_Chr_Cp('R');

 delay_ms(2000);
 pageState = 0;


 boxes = EEPROM_Read( 0x00 );
 sortMin = EEPROM_Read( 0x01 );
 sortSec = EEPROM_Read( 0x02 );
 sortQty = (EEPROM_Read( 0x03  + 1) << 8) | EEPROM_Read( 0x03 );
 jobLimit = EEPROM_Read( 0x05 );

 if(EEPROM_Read( 0x10 ) != 42){
 boxes = 0; sortMin = 0; sortSec = 3; sortQty = 5; jobLimit = 4;
 }

 bkpQty = sortQty;
 bkpSortMin = sortMin;
 bkpSortSec = sortSec;
 bkpJobLimit = jobLimit;
 refreshUI();

 while (1) {
  if(PORTA.B6 == 1)ems_halt() ;

 if( PORTA.B2  ||  PORTA.B3 ){
 char enterFlag;
 enterFlag =  PORTA.B2 ;
 while( PORTA.B2  ||  PORTA.B3 );

 if(pageState == 0){
 if(enterFlag){
 pageState = 1;

 if(EEPROM_Read( 0x10 ) != 42) {
 EEPROM_Write( 0x00 , boxes);
 adj = 4;
 pageState = 3;
 }
 }
 else
 pageState = 2;
 }
 else if(pageState == 1){
 if(!enterFlag){
 pageState = 2;
 adj = 1;
  PORTB.B2  = 0;
 }
 }
 else if(pageState == 2){
 if(enterFlag){
 adj++;
 if(adj > 4)
 pageState = 3;
 }
 else
 pageState = 3;
 }
 else if(pageState == 3){
 if(enterFlag){

 EEPROM_Write( 0x01 , sortMin);
 EEPROM_Write( 0x02 , sortSec);
 EEPROM_Write( 0x05 , jobLimit);
 EEPROM_Write( 0x10 , 42);


 EEPROM_Write( 0x03 , (char)sortQty);
 delay_ms(20);
 EEPROM_Write( 0x03  + 1, (char)(sortQty >> 8));
 delay_ms(20);

 if(sortQty != bkpQty || jobLimit != bkpJobLimit){
 boxes = 0;
 obj = 0;
 }

 bkpQty = sortQty;
 bkpJobLimit = jobLimit;
 bkpSortMin = sortMin;
 bkpSortSec = sortSec;

  PORTA.B7  = 1;
 for(obj=0; obj<10000; obj++);
  PORTA.B7  = 0;
 obj = 0;

 }
 else{
 sortQty = bkpQty;
 sortMin = bkpSortMin;
 sortSec = bkpSortSec;
 jobLimit = bkpJobLimit;
 adj = 0;
 }
 pageState = 0;
 }
 refreshUI();

 }

 if(pageState == 1){
 if(boxes >= jobLimit)
 boxes = 0;
 else{
  PORTB.B2  = 1;
 objectCount();
 }
 }else if(pageState == 2){
 if( PORTA.B0  ||  PORTA.B1 ){
 short d;
 if( PORTA.B0 )
 d = 1;
 else
 d = -1;

 if(adj == 1){
 sortMin += d;
 if(sortMin > 1)
 sortMin = 0;
 if(sortMin < 0)
 sortMin = 1;
 }
 else if(adj == 2){
 sortSec += d;
 if(sortSec > 59)
 sortSec = 0;
 if(sortSec < 0)
 sortSec = 59;
 }
 else if(adj == 3){
 sortQty += d;
 if(sortQty > 999)
 sortQty = 1;
 if(sortQty < 1)
 sortQty = 999;
 }
 else if(adj == 4){
 jobLimit += d;
 if(jobLimit > 99)
 jobLimit = 1;
 if(jobLimit < 1)
 jobLimit = 99;
 }
 refreshUI();
 while( PORTA.B0  ||  PORTA.B1 );
 }
 }
 }
}




void refreshUI() {


 if (pageState != lastPage) {
 Lcd_Cmd(0x0C);
 Lcd_Cmd(_LCD_CLEAR);

 if (pageState == 0 || pageState == 3) {
 if (pageState == 0)
 Lcd_Out(1,6,"START?");

 else
 Lcd_Out(1,6,"SAVE?");


 Lcd_Out(2,5,"ENT/ESC");

 }
 else {
 if (pageState == 1)
 Lcd_Out(1,6,"RUNNING");
 else
 Lcd_Out(1,3,"Sort:   m   s");


 Lcd_Out(2,3,"Pc:    Box:");
 }
 lastPage = pageState;
 }


 if (pageState == 1) {
 disp_num(obj, 2, 6, VAL_CEN);
 disp_num(boxes, 2, 14, VAL_DEZ);
 }
 else if (pageState == 2) {
 disp_num(sortMin, 1, 10, VAL_UNI);
 disp_num(sortSec, 1, 13, VAL_DEZ);
 disp_num(sortQty, 2, 6, VAL_CEN);
 disp_num(jobLimit, 2, 14, VAL_DEZ);


 if(adj == 1)
 disp_blink(1, 9);
 if(adj == 2)
 disp_blink(1, 13);
 if(adj == 3)
 disp_blink(2, 7);
 if(adj == 4)
 disp_blink(2, 14);
 }
}




void objectCount() {
 static char objFlag = 0;
 objTick++;

 if(objTick >=  18335 ){
 objTick = 0;
 objTimeOut++;
 if(objTimeOut >= 30){
 while(1){
 Lcd_Out(1,4,"OBJ TIMEOUT");
  PORTB.B2  = 0;
  PORTA.B7  = 1;
 }
 }
 }

 if( PORTA.B4 )objFlag = 1;

 if (! PORTA.B4  && objFlag) {
 objTick = 0;
 objTimeOut = 0;
 obj++;
 refreshUI();

 if (obj >= sortQty) {
  PORTB.B2  = 0;
  PORTB.B3  = 1;
 Lcd_Out(1,5,"SORTING..");


 totalSortSeconds = ((sortMin << 6) - (sortMin << 2)) + sortSec;

 for(bkpSortSec = 0; bkpSortSec < totalSortSeconds; bkpSortSec++) {

 for(obj = 0; obj < 20; obj++) {
  if(PORTA.B6 == 1)ems_halt() ;
 delay_ms(50);
 }
 }

  PORTB.B3  = 0;
 obj = 0;
 boxes++;
 EEPROM_Write( 0x00 , boxes);

 if (jobLimit > 0 && boxes >= jobLimit) {
  PORTB.B2  = 0;
 pageState = 0;
 boxes = 0;
 EEPROM_Write( 0x00 , boxes);
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1,5,"JOB END");
  PORTA.B7  = 1;
 while(1);
 }
 lastPage = 0xFF;
 refreshUI();
 }
 objFlag = 0;
 }
}





void disp_num(unsigned int num, char row, char col, DispFormat range){
 char dezM, mil, cen, dez, uni, size;
 short noZero = 0;

 switch(range){

 case VAL_DEZM:

 dezM = (char)(num/10000);
 num %= 10000;
 mil = (char)(num/1000);
 num %= 1000;
 cen = (char)(num/100);
 num %= 100;
 dez = (char)(num/10);
 uni = (char)(num%10);

 if(!dezM && !noZero)
 Lcd_Chr(row, col, ' ');
 else{
 Lcd_Chr(row, col, dezM+0x30);
 noZero = 1;
 }

 if(!mil && !noZero) Lcd_Chr_Cp(' ');

 else{
 Lcd_Chr_Cp(mil+0x30);
 noZero = 1;
 }

 if(!cen && !noZero) Lcd_Chr_Cp(' ');

 else{
 Lcd_Chr_Cp(cen+0x30);
 noZero = 1;
 }

 if(!dez && !noZero) Lcd_Chr_Cp(' ');

 else{
 Lcd_Chr_Cp(dez+0x30);
 noZero = 1;
 }

 Lcd_Chr_Cp(uni+0x30);
 break;

 case VAL_MIL:

 mil = (char)(num/1000);
 num %= 1000;
 cen = (char)(num/100);
 num %= 100;
 dez = (char)(num/10);
 uni = (char)(num%10);

 if(!mil && !noZero) Lcd_Chr(row, col, ' ');

 else{
 Lcd_Chr(row,col,mil+0x30);
 noZero = 1;
 }

 if(!cen && !noZero) Lcd_Chr_Cp(' ');

 else{
 Lcd_Chr_Cp(cen+0x30);
 noZero = 1;
 }

 if(!dez && !noZero) Lcd_Chr_Cp(' ');

 else{
 Lcd_Chr_Cp(dez+0x30);
 noZero = 1;
 }

 Lcd_Chr_Cp(uni+0x30);
 break;

 case VAL_CEN:

 cen = (char)(num/100);
 num %= 100;
 dez = (char)(num/10);
 uni = (char)(num%10);

 if(!cen && !noZero) Lcd_Chr(row, col, ' ');

 else{
 Lcd_Chr(row, col, cen+0x30);
 noZero = 1;
 }

 if(!dez && !noZero) Lcd_Chr_Cp(' ');

 else{
 Lcd_Chr_Cp(dez+0x30);
 noZero = 1;
 }

 Lcd_Chr_Cp(uni+0x30);
 break;

 case VAL_DEZ:

 dez = (char)(num/10);
 uni = (char)(num%10);

 if(!dez && !noZero) Lcd_Chr(row, col, ' ');

 else{
 Lcd_Chr(row, col, dez+0x30);
 noZero = 1;
 }

 Lcd_Chr_Cp(uni+0x30);
 break;

 case VAL_UNI:
 Lcd_Chr(row, col, num+0x30);

 break;

 default:
 Lcd_Chr(row, col, num+0x30);
 }
}




void disp_blink(char row, char col){
 if(row == 1) Lcd_Cmd(0x80 + col);
 else Lcd_Cmd(0xC0 + col);

 Lcd_Cmd(0x0D);
 delay_us(100);
}
